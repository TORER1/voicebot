from gtts import gTTS
import playsound
import random
b = ("q, w, e, r, t, z, u, i, o, p, ü, a, s, d, f, g, h, j, k, l, ö, ä, y, x, c,v ,b ,n , m")
a = random.choice(b)
text_val = str(input("ENTER YOUR TEXT ON ENGLISH: "))
language = 'en'

obj = gTTS(text=text_val, lang=language, slow=False)
obj.save(a + ".mp3")
