you must to install these libraries:

playsound
gtts


----- YOU CAN TO FOUND LIBRARIES HERE-----

https://pypi.org/project/playsound/

command for gtts:

pip install gTTS


----------------------------------------------


files .mp3 will in these folder
